from os import name
from django.http.response import HttpResponse
from django.shortcuts import render
from django.views.generic import ListView
from .models import Data

def homepageview(request):
    return render(request,'home.html')

def aboutpageview(request):
    return render(request,'about.html')

def contactpageview(request):

    if request.method == "POST":
        print("This Is a post")
    
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        Gender=request.POST.get('Gender')
        
        data = Data(name=name,email=email,phone=phone,Gender=Gender)
        data.save()
        print('Data is submited ')

    return render(request,'contact.html')    